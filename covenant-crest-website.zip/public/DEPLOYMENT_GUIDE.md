# Covenant Crest Group Ltd - Website Deployment Guide

## 📋 Overview

Your website consists of:
- **Frontend**: Static HTML pages served from the `public/` folder
- **Backend**: Node.js/Express API for managing jobs, contacts, and admin authentication
- **Storage**: File-based JSON storage (no database required)

## 🚀 Deployment Strategy

You have two options:

### Option 1: Deploy Frontend to Netlify (Recommended for Front-end)
- Your HTML, CSS, and JavaScript files automatically deploy when you push to GitHub
- Fast, free, and already configured

### Option 2: Full Stack Deployment (Frontend + Backend)
- Deploy frontend to Netlify (as before)
- Deploy backend to a Node.js hosting service (Heroku, Railway, Render, etc.)
- Update API endpoint in your admin dashboard

---

## 🛠️ Backend Deployment Steps

### Step 1: Prepare Your Server Files

Your server is ready in the root directory:
- `server.js` - Main backend application
- `package.json` - Dependencies list
- `public/` - All frontend files
- `data/` - Data storage (created automatically on first run)

### Step 2: Choose a Hosting Platform

#### **Option A: Heroku (Free tier available)**
1. Sign up at https://www.heroku.com
2. Install Heroku CLI
3. In your project root:
   ```bash
   heroku login
   heroku create your-app-name
   git push heroku main
   ```
4. Your backend will be available at: `https://your-app-name.herokuapp.com`

#### **Option B: Railway.app (Simple, $5/month)**
1. Sign up at https://railway.app
2. Connect your GitHub repository
3. Railway automatically detects Node.js and deploys
4. Your backend URL will be provided in the dashboard

#### **Option C: Render.com (Free tier)**
1. Sign up at https://render.com
2. Create new Web Service from GitHub
3. Select your repository
4. Set Start Command: `node server.js`
5. Deploy and get your backend URL

#### **Option D: DigitalOcean App Platform ($12/month)**
1. Sign up at https://www.digitalocean.com
2. Create new App from GitHub
3. Configure to run Node.js
4. Set start command: `node server.js`

### Step 3: Set Environment Variables

Create a `.env` file in your project root (or set in your hosting platform's dashboard):

```
PORT=3000
JWT_SECRET=your-super-secret-key-change-this-to-something-long-and-random
NODE_ENV=production
```

**Important**: Replace `JWT_SECRET` with a secure random string (at least 32 characters).

Generate a secure secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Step 4: Create Initial Admin Account

Once your backend is deployed:

1. Use a tool like Postman or curl to create your admin account:
   ```bash
   curl -X POST https://your-backend-url.com/api/admin/create-account \
     -H "Content-Type: application/json" \
     -d '{"email":"jaby.k@covenantcrest.co.uk","password":"your-password"}'
   ```

2. Or use the built-in setup form by visiting `/login.html` and clicking "Create account"

### Step 5: Test Your Backend

Test each endpoint to ensure it's working:

```bash
# Test login
curl -X POST https://your-backend-url.com/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"email":"jaby.k@covenantcrest.co.uk","password":"your-password"}'

# Test contact submission
curl -X POST https://your-backend-url.com/api/contact \
  -H "Content-Type: application/json" \
  -d '{
    "name":"John Smith",
    "email":"john@example.com",
    "subject":"Inquiry",
    "message":"Hello"
  }'
```

---

## 🌐 Frontend Deployment (Netlify)

1. Your frontend is already connected to Netlify
2. When you push to GitHub, Netlify automatically rebuilds and deploys
3. Your site is available at your Netlify domain

**Important**: Update your admin dashboard to use your backend API:

### Updating API Endpoints

If your backend is on a different domain than your frontend:

1. Open `public/admin.html` in your editor
2. Find all `fetch('/')` calls
3. Replace with your backend URL:
   ```javascript
   fetch('https://your-backend-url.com/api/jobs')
   ```

Or add a configuration at the top of admin.html:
```javascript
const API_BASE = 'https://your-backend-url.com';
// Then use: fetch(API_BASE + '/api/jobs')
```

---

## 📁 File Structure

```
covenant-crest-website/
├── server.js                 # Backend Express app
├── package.json              # Node.js dependencies
├── .env                       # Environment variables (don't commit!)
├── data/                      # Auto-created data storage
│   ├── admins.json           # Admin accounts
│   ├── jobs.json             # Job listings
│   ├── contacts.json         # Contact form submissions
│   └── content.json          # Service page content
└── public/                    # Frontend files
    ├── index.html            # Home page
    ├── haulage.html          # Haulage services page
    ├── trade.html            # Trade/import services page
    ├── admin.html            # Admin dashboard
    ├── login.html            # Admin login page
    └── DEPLOYMENT_GUIDE.md   # This file
```

---

## 🔐 Security Checklist

Before going live:

- [ ] Change `JWT_SECRET` to a random, secure value
- [ ] Set `NODE_ENV=production`
- [ ] Enable HTTPS (automatic on Heroku, Railway, Render)
- [ ] Use strong admin password (12+ characters, mixed case, numbers, symbols)
- [ ] Don't commit `.env` file to GitHub
- [ ] Review CORS settings in `server.js` if needed
- [ ] Set up automated backups for your `data/` folder

---

## 📞 API Endpoints Reference

All endpoints are available at your backend URL.

### Authentication
- `POST /api/admin/create-account` - Create first admin account
- `POST /api/admin/login` - Login and get JWT token

### Jobs Management
- `GET /api/jobs` - List all jobs
- `GET /api/jobs/:id` - Get specific job
- `POST /api/jobs` - Create job (requires token)
- `PUT /api/jobs/:id` - Update job (requires token)
- `DELETE /api/jobs/:id` - Delete job (requires token)

### Contact Form
- `POST /api/contact` - Submit contact form
- `GET /api/admin/contacts` - View all contacts (requires token)
- `PUT /api/admin/contacts/:id` - Update contact status (requires token)

### Content Management
- `GET /api/content` - Get all content
- `PUT /api/content/:section` - Update content section (requires token)

---

## 🚨 Troubleshooting

### "Cannot POST /api/contact"
- Check that your backend is running and accessible
- Verify the URL in your frontend (index.html, haulage.html, trade.html)

### "Invalid token" error
- Create a new admin account using the `/login.html` setup form
- Ensure your JWT_SECRET environment variable is set

### "CORS error"
- Make sure backend is accessible from your frontend domain
- CORS is enabled in server.js by default

### Data not persisting
- Check that the `data/` folder exists in your hosting environment
- Some hosting platforms delete files after deployment; use a database instead (upgrade to MongoDB Atlas)

### Admin page won't load
- Open browser console (F12) and check for errors
- Verify your admin has a valid JWT token in localStorage
- Check that backend API is accessible

---

## 📈 Next Steps

1. **Email Notifications**: Configure Zoho email in server.js contact endpoint
2. **Database**: Replace JSON files with MongoDB Atlas for production
3. **Analytics**: Add Google Analytics to track visitor behavior
4. **SSL Certificate**: Ensure HTTPS (automatic on recommended platforms)
5. **Backups**: Set up regular backups of your data folder
6. **CDN**: Use Cloudflare for faster content delivery

---

## 📞 Support

For issues with:
- **Frontend**: Check browser console (F12)
- **Backend**: Check server logs on your hosting platform
- **GitHub**: Review git history and recent commits
- **Deployment**: Check your hosting platform's dashboard for build logs

---

## 📝 Quick Reference Commands

### Local Development
```bash
npm install
npm run dev          # Runs with nodemon (auto-reload)
npm start            # Production mode
```

### Accessing Admin Dashboard
- Frontend: `http://localhost:3000` (or your domain)
- Admin: `http://localhost:3000/admin.html`
- Login: `http://localhost:3000/login.html`

---

## ✅ Deployment Checklist

- [ ] Backend deployed to hosting platform
- [ ] Environment variables configured
- [ ] Admin account created
- [ ] Frontend updated with backend URL (if using separate domain)
- [ ] Contact form tested
- [ ] Admin dashboard tested
- [ ] All pages load correctly
- [ ] No console errors
- [ ] SSL/HTTPS working
- [ ] Domain configured correctly

You're ready to launch! 🎉
