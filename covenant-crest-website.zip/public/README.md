# Covenant Crest Group Ltd - Professional Website

Professional website for Covenant Crest Group Ltd with separate service pages for Haulage and Trade/Import divisions, complete backend system, and admin dashboard.

## 🎯 Features

- **Professional Frontend**: Responsive design with separate pages for each service
- **Admin Dashboard**: Full-featured dashboard to manage jobs, contacts, and content
- **Authentication**: Secure login with JWT tokens and password hashing
- **Job Management**: Create, edit, and delete job listings
- **Contact Management**: Receive and manage customer inquiries
- **Content Management**: Update service descriptions without code changes
- **Real-time Updates**: All changes immediately visible on the website

## 📄 Pages

- **Home** (`index.html`) - Company overview with service highlights
- **Haulage Services** (`haulage.html`) - Dedicated haulage and logistics page
- **Trade & Import** (`trade.html`) - Dedicated international trade page
- **Admin Dashboard** (`admin.html`) - Complete management system
- **Admin Login** (`login.html`) - Secure admin authentication

## 🏃 Quick Start

### 1. Local Development

```bash
# Install dependencies
npm install

# Start development server (auto-reload)
npm run dev

# Start production server
npm start
```

Server runs on `http://localhost:3000`

### 2. Create Initial Admin Account

Visit `http://localhost:3000/login.html` and click "Create account" to set up your admin login with email and password.

### 3. Access Admin Dashboard

- Login at `http://localhost:3000/login.html`
- Access dashboard at `http://localhost:3000/admin.html`

## 🚀 Deployment

See `DEPLOYMENT_GUIDE.md` for detailed instructions on deploying to:
- Heroku (free tier available)
- Railway.app
- Render.com
- DigitalOcean
- Any Node.js hosting platform

### Quick Deployment Steps

1. **Frontend**: Push to GitHub, Netlify auto-deploys
2. **Backend**: Deploy to Node.js hosting platform
3. **Create Admin**: Run setup form or use API endpoint
4. **Configure**: Update backend URL in admin dashboard if needed

## 📁 Project Structure

```
├── server.js              # Express backend
├── package.json           # Dependencies
├── public/
│   ├── index.html        # Home page
│   ├── haulage.html      # Haulage services
│   ├── trade.html        # Trade services
│   ├── admin.html        # Admin dashboard
│   ├── login.html        # Login page
│   ├── README.md         # This file
│   └── DEPLOYMENT_GUIDE.md
└── data/                 # Auto-created on first run
    ├── admins.json
    ├── jobs.json
    ├── contacts.json
    └── content.json
```

## 🔐 Security

- Passwords hashed with bcrypt
- JWT token-based authentication
- All admin actions require valid token
- Contact form has basic validation
- CORS enabled for safe cross-origin requests

## 📊 API Endpoints

### Authentication
- `POST /api/admin/create-account` - Create admin account
- `POST /api/admin/login` - Admin login

### Jobs
- `GET /api/jobs` - List all jobs
- `POST /api/jobs` - Create job (admin only)
- `PUT /api/jobs/:id` - Update job (admin only)
- `DELETE /api/jobs/:id` - Delete job (admin only)

### Contacts
- `POST /api/contact` - Submit contact form
- `GET /api/admin/contacts` - View contacts (admin only)
- `PUT /api/admin/contacts/:id` - Update contact (admin only)

### Content
- `GET /api/content` - Get all content
- `PUT /api/content/:section` - Update content (admin only)

## 🛠️ Environment Variables

Create a `.env` file in the root directory:

```
PORT=3000
JWT_SECRET=your-secure-random-string-here
NODE_ENV=production
```

Generate secure JWT_SECRET:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## 📝 Admin Features

### Dashboard
- View statistics (total jobs, new contacts)
- Quick access to all management sections

### Jobs Management
- Create new job listings
- Edit existing jobs
- Delete jobs
- Track job status

### Contact Management
- View all contact form submissions
- Update contact status
- Filter by status

### Content Management
- Edit Haulage service descriptions
- Edit Trade service descriptions
- Update content without touching code

## 🎨 Branding

Professional color scheme:
- Navy: `#0D1B2A`
- Gold: `#C9A84C`
- Cream: `#FAF7F0`
- Responsive design for all devices

## 💾 Data Storage

Currently using file-based JSON storage:
- `admins.json` - Admin accounts
- `jobs.json` - Job listings
- `contacts.json` - Contact submissions
- `content.json` - Service descriptions

**For Production**: Consider upgrading to MongoDB Atlas for scalability and reliability.

## 🔄 How It Works

1. **Static Frontend**: HTML, CSS, JavaScript served instantly
2. **Dynamic Backend**: Node.js/Express handles all data operations
3. **Authentication**: JWT tokens secure admin access
4. **Real-time Updates**: Admin changes immediately reflected on site
5. **Data Persistence**: JSON files store all information

## ⚠️ Before Going Live

- [ ] Change JWT_SECRET to secure value
- [ ] Create admin account with strong password
- [ ] Test all forms (contact, job creation, etc.)
- [ ] Verify responsive design on mobile
- [ ] Set up email notifications (optional)
- [ ] Enable HTTPS on production server
- [ ] Configure backups for data folder
- [ ] Review security checklist in DEPLOYMENT_GUIDE.md

## 📞 Admin Email

Default admin email: `jaby.k@covenantcrest.co.uk`

You can create multiple admin accounts through the admin dashboard.

## 🚀 Performance Tips

- Frontend is served as static files (very fast)
- Backend uses JSON storage (suitable for small-medium businesses)
- Consider CDN for global delivery
- Enable gzip compression on server
- Minify CSS/JS in production

## 📞 Support & Troubleshooting

### Common Issues

**Admin page won't load?**
- Check that you're logged in (token in localStorage)
- Open browser console (F12) to see errors
- Verify backend is running

**Forms not working?**
- Check that backend URL is correct in admin.html
- Verify backend is accessible from your domain
- Check network tab in browser dev tools

**Data not saving?**
- Ensure data/ folder exists
- Check file permissions on server
- Review server logs for errors

## 📈 Future Enhancements

- Database migration (MongoDB Atlas)
- Email notifications on contact submission
- Job application system
- User testimonials section
- Blog/News section
- Multi-language support
- Analytics dashboard
- Email marketing integration

## 📄 License

ISC License - See package.json

---

**Ready to deploy?** Follow the steps in `DEPLOYMENT_GUIDE.md` to get your site live! 🎉
