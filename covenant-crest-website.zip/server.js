const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Secret key for JWT - change this to a strong random string
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Database simulation (in production, use MongoDB or PostgreSQL)
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

// Admin user data file
const adminsFile = path.join(dataDir, 'admins.json');
const jobsFile = path.join(dataDir, 'jobs.json');
const contactsFile = path.join(dataDir, 'contacts.json');
const contentFile = path.join(dataDir, 'content.json');

// Initialize files if they don't exist
if (!fs.existsSync(adminsFile)) {
  fs.writeFileSync(adminsFile, JSON.stringify([], null, 2));
}
if (!fs.existsSync(jobsFile)) {
  fs.writeFileSync(jobsFile, JSON.stringify([], null, 2));
}
if (!fs.existsSync(contactsFile)) {
  fs.writeFileSync(contactsFile, JSON.stringify([], null, 2));
}
if (!fs.existsSync(contentFile)) {
  fs.writeFileSync(contentFile, JSON.stringify({
    haulage: { title: 'Haulage & Logistics', description: 'Professional freight and logistics services across the UK' },
    trade: { title: 'Import & Distribution', description: 'Global trade and distribution solutions' },
    recruitment: { title: 'Recruitment', description: 'Expert staffing and recruitment services' }
  }, null, 2));
}

// Utility functions
const readJSON = (file) => JSON.parse(fs.readFileSync(file, 'utf8'));
const writeJSON = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2));

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.admin = decoded;
    next();
  } catch (err) {
    res.status(403).json({ error: 'Invalid token' });
  }
};

// ============ AUTHENTICATION ENDPOINTS ============

// Create initial admin account (run once)
app.post('/api/admin/create-account', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const admins = readJSON(adminsFile);
  if (admins.find(a => a.email === email)) {
    return res.status(400).json({ error: 'Admin account already exists' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const admin = {
    id: uuidv4(),
    email,
    password: hashedPassword,
    createdAt: new Date().toISOString()
  };

  admins.push(admin);
  writeJSON(adminsFile, admins);

  res.json({ message: 'Admin account created successfully', email });
});

// Login endpoint
app.post('/api/admin/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const admins = readJSON(adminsFile);
  const admin = admins.find(a => a.email === email);

  if (!admin) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const validPassword = await bcrypt.compare(password, admin.password);
  if (!validPassword) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: admin.id, email: admin.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, email: admin.email });
});

// ============ JOB ENDPOINTS ============

// Get all jobs
app.get('/api/jobs', (req, res) => {
  const jobs = readJSON(jobsFile);
  res.json(jobs);
});

// Get job by ID
app.get('/api/jobs/:id', (req, res) => {
  const jobs = readJSON(jobsFile);
  const job = jobs.find(j => j.id === req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});

// Create job (admin only)
app.post('/api/jobs', verifyToken, (req, res) => {
  const { title, sector, type, location, pay, description, requirements } = req.body;

  if (!title || !sector || !location) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const jobs = readJSON(jobsFile);
  const newJob = {
    id: uuidv4(),
    title,
    sector,
    type: type || 'full-time',
    location,
    pay: pay || 'Competitive',
    description,
    requirements,
    status: 'active',
    createdAt: new Date().toISOString(),
    applications: 0
  };

  jobs.push(newJob);
  writeJSON(jobsFile, jobs);
  res.status(201).json(newJob);
});

// Update job (admin only)
app.put('/api/jobs/:id', verifyToken, (req, res) => {
  const jobs = readJSON(jobsFile);
  const jobIndex = jobs.findIndex(j => j.id === req.params.id);

  if (jobIndex === -1) return res.status(404).json({ error: 'Job not found' });

  jobs[jobIndex] = { ...jobs[jobIndex], ...req.body, id: req.params.id };
  writeJSON(jobsFile, jobs);
  res.json(jobs[jobIndex]);
});

// Delete job (admin only)
app.delete('/api/jobs/:id', verifyToken, (req, res) => {
  const jobs = readJSON(jobsFile);
  const filteredJobs = jobs.filter(j => j.id !== req.params.id);

  if (filteredJobs.length === jobs.length) {
    return res.status(404).json({ error: 'Job not found' });
  }

  writeJSON(jobsFile, filteredJobs);
  res.json({ message: 'Job deleted' });
});

// ============ CONTACT FORM ENDPOINTS ============

// Submit contact form
app.post('/api/contact', (req, res) => {
  const { name, email, phone, subject, message } = req.body;

  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const contacts = readJSON(contactsFile);
  const newContact = {
    id: uuidv4(),
    name,
    email,
    phone,
    subject,
    message,
    status: 'new',
    submittedAt: new Date().toISOString()
  };

  contacts.push(newContact);
  writeJSON(contactsFile, contacts);

  // Send email notification (configure with your email service)
  console.log('New contact submission:', newContact);

  res.status(201).json({ message: 'Thank you for your inquiry. We will contact you soon.' });
});

// Get contact submissions (admin only)
app.get('/api/admin/contacts', verifyToken, (req, res) => {
  const contacts = readJSON(contactsFile);
  res.json(contacts);
});

// Update contact status (admin only)
app.put('/api/admin/contacts/:id', verifyToken, (req, res) => {
  const contacts = readJSON(contactsFile);
  const contactIndex = contacts.findIndex(c => c.id === req.params.id);

  if (contactIndex === -1) return res.status(404).json({ error: 'Contact not found' });

  contacts[contactIndex] = { ...contacts[contactIndex], ...req.body };
  writeJSON(contactsFile, contacts);
  res.json(contacts[contactIndex]);
});

// ============ CONTENT ENDPOINTS ============

// Get content
app.get('/api/content', (req, res) => {
  const content = readJSON(contentFile);
  res.json(content);
});

// Update content (admin only)
app.put('/api/content/:section', verifyToken, (req, res) => {
  const content = readJSON(contentFile);

  if (!content[req.params.section]) {
    return res.status(404).json({ error: 'Content section not found' });
  }

  content[req.params.section] = { ...content[req.params.section], ...req.body };
  writeJSON(contentFile, content);
  res.json(content[req.params.section]);
});

// ============ ERROR HANDLING ============

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log('To create admin account, POST to /api/admin/create-account with { email, password }');
});

module.exports = app;
